# TinyLanderV1.0
Tiny Lander like Lunar Lander for ARDUBOY
I am a big fan of the tiny joypad platform.
This is my first game for the ARDUBOY... it was a lot of fun to develop it..
based on the many templates (examples) provided by the platform:
https://www.tinyjoypad.com
Big thanks to all of them! :)
